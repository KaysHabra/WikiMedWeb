import { Component, EventEmitter, forwardRef, Input, OnInit, Output } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';

@Component({
  selector: 'app-mat-datepicker2',
  templateUrl: './mat-datepicker2.component.html',
  styleUrls: ['./mat-datepicker2.component.scss'],

  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => MatDatepicker2Component),
      multi: true
    }
  ]
})
export class MatDatepicker2Component implements OnInit {
  // [(ngModel)]من اجل تفعيل 
  // دالة تُستدعى عند تغيير القيمة
  onChange: any = () => { };

  // دالة تُستدعى عند لمس المكون
  onTouched: any = () => { };
  // تعيين القيمة من ngModel إلى المكون
  writeValue(value: any): void {
    this.counterNumber = value;
  }

  // تسجيل دالة التغيير
  registerOnChange(fn: any): void {
    this.onChange = fn;
  }

  // تسجيل دالة اللمس
  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }

  // تعطيل أو تمكين المكون (اختياري)
  setDisabledState?(isDisabled: boolean): void {
    // يمكنك تنفيذ هذا إذا كنت تريد دعم تعطيل المكون
  }


  @Input() disabled = false;

  @Input() Label = '';

  @Input()
  counterNumber = '';

  @Output() counterNumberChange: EventEmitter<any> = new EventEmitter<any>();

  constructor() { }

  ngOnInit() { }

  export(ev) {
    console.log(`cdcdcd= `, ev.value);
    // this.counterNumber = this.counterNumber.split("/").reverse().join("-");

    var date = new Date(ev.value);
    let newdate = this.formatDate(date);
    this.onChange(newdate);
    // alert(newdate);
    this.counterNumberChange.emit(newdate);
  }

  formatDate(date) {
    var d = new Date(date),
      month = '' + (d.getMonth() + 1),
      day = '' + d.getDate(),
      year = d.getFullYear();

    if (month.length < 2)
      month = '0' + month;
    if (day.length < 2)
      day = '0' + day;

    return [year, month, day].join('-');
  }







  // عند الإدخال
  // onDateInput(event: any): void {
  //   let value = event.target.value;

  //   // السماح فقط بالأرقام في المواضع الصحيحة والحفاظ على الفواصل
  //   value = value
  //     .replace(/[^\d/]/g, '') // إزالة الأحرف غير الأرقام أو '/'
  //     .replace(/^(\d{2})(?!\/)/, '$1/') // إضافة '/' بعد اليوم إذا لم يكن موجودًا
  //     .replace(/^(\d{2}\/\d{2})(?!\/)/, '$1/'); // إضافة '/' بعد الشهر إذا لم يكن موجودًا

  //   // تقليم النص بحيث لا يتجاوز التنسيق dd/mm/yyyy
  //   this.counterNumber = value.substring(0, 10);
  // }

  // // عند التركيز على الحقل
  // onDateFocus(): void {
  //   if (this.counterNumber === 'dd/mm/yyyy') {
  //     this.counterNumber = ''; // تفريغ القيمة الافتراضية
  //   }
  // }

  // // عند الخروج من الحقل
  // onDateBlur(): void {
  //   if (!this.counterNumber.match(/^\d{2}\/\d{2}\/\d{4}$/)) {
  //     this.counterNumber = 'dd/mm/yyyy'; // إعادة التنسيق الافتراضي
  //   }
  // }


  onDateInput(event: any): void {
    let value = event.target.value;

    // السماح فقط بالأرقام
    value = value.replace(/[^\d]/g, '');

    // إضافة الفواصل تلقائيًا عند إدخال النص
    if (value.length > 4 && value.length <= 6) {
      value = value.slice(0, 4) + '-' + value.slice(4);
    } else if (value.length > 6) {
      value = value.slice(0, 4) + '-' + value.slice(4, 6) + '-' + value.slice(6, 8);
    }

    // تقليم النص بحيث لا يتجاوز الطول المسموح به
    value = value.substring(0, 10);

    // تحديث القيمة
    this.counterNumber = value;
    console.log(` this.counterNumber= `, this.counterNumber);

    if (this.isValidDate(value)) {
      this.onChange(value);
      // alert(newdate);
      this.counterNumberChange.emit(value);
    }
  }

  // عند التركيز على الحقل
  onDateFocus(): void {
    if (this.counterNumber === 'yyyy-MM-dd') {
      this.counterNumber = ''; // تفريغ القيمة الافتراضية
    }
  }

  // عند الخروج من الحقل
  onDateBlur(): void {
    if (!this.isValidDate(this.counterNumber)) {
      this.counterNumber = 'yyyy-MM-dd'; // إعادة التنسيق الافتراضي
    }
  }

  isValidDate(dateString: string): boolean {
    const regex = /^\d{4}-\d{2}-\d{2}$/;

    // التحقق من الصيغة العامة
    if (!regex.test(dateString)) return false;

    // تحويل النص إلى كائن تاريخ
    const [year, month, day] = dateString.split('-').map(Number);
    const date = new Date(year, month - 1, day);

    // التحقق من القيم الفعلية
    return (
      date.getFullYear() === year &&
      date.getMonth() === month - 1 &&
      date.getDate() === day
    );
  }
}

