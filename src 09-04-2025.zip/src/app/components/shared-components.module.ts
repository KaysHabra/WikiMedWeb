import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { FormsModule } from '@angular/forms';

import { NewAppComponent } from './new-app/new-app.component';
import { SelectAutocompleteComponent } from './select-autocomplete/select-autocomplete.component';
import { TreeViewComponent } from './tree-view/tree-view.component';
import { MatTreeModule } from '@angular/material/tree';
import { MatButtonModule } from '@angular/material/button';
import { TreeViewSelectionComponent } from './tree-view-selection/tree-view-selection.component';
import { TimePickerComponent } from './time-picker/time-picker.component';
import { PatientAddEditComponent } from './patient-add-edit/patient-add-edit.component';
import { PatientAppointmentsComponent } from './patient-appointments/patient-appointments.component';
import { TranslateModule } from '@ngx-translate/core';
import { MatDatepickerComponent } from './mat-datepicker/mat-datepicker.component';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { ScheduleTimeComponent } from './schedule-time/schedule-time.component';
import { MatDatepicker2Component } from './mat-datepicker2/mat-datepicker2.component';
import { KaysDatepickerComponent } from './kays-datepicker/kays-datepicker.component';
import { DoctorShiftComponent } from './doctor-shift/doctor-shift.component';
import { NextAvailableComponent } from './next-available/next-available.component';

import {MatIconModule} from '@angular/material/icon';
import { MatTreeViewComponent } from './mat-tree-view/mat-tree-view.component';
import { SelectAutocompleteServerComponent } from './select-autocomplete-server/select-autocomplete-server.component';
import { DatePickerComponent } from './date-picker/date-picker.component';
import { MatAutocompleteServerComponent } from './mat-autocomplete-server/mat-autocomplete-server.component';
import { GptAutocompleteComponent } from './gpt-autocomplete/gpt-autocomplete.component';
import { TimeInputMaskDirective } from '../directives/time-input-mask.directive';
import { TimeInputComponent } from './time-input/time-input.component';
import { MatInputModule } from '@angular/material/input';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { W3AutocompleteComponent } from './w3-autocomplete/w3-autocomplete.component';
import { PatientSelectAutoComponent } from './patient-select-auto/patient-select-auto.component';

@NgModule({
  declarations: [NewAppComponent, SelectAutocompleteComponent, TreeViewComponent, TreeViewSelectionComponent,
    TimePickerComponent, PatientAddEditComponent, PatientAppointmentsComponent, 
    MatDatepickerComponent, MatDatepicker2Component, ScheduleTimeComponent, KaysDatepickerComponent, 
    DoctorShiftComponent, NextAvailableComponent, MatTreeViewComponent, SelectAutocompleteServerComponent, 
    DatePickerComponent, GptAutocompleteComponent, TimeInputMaskDirective, TimeInputComponent, 
    W3AutocompleteComponent, PatientSelectAutoComponent, ],
  imports: [
    CommonModule,
    IonicModule.forRoot(),
    // BrowserModule,
    FormsModule,
    MatTreeModule,
    MatButtonModule,
    TranslateModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatIconModule,

    MatInputModule,
    MatCardModule,
    MatFormFieldModule,
    
  ],
  exports: [NewAppComponent, SelectAutocompleteComponent, TreeViewComponent, TreeViewSelectionComponent,
    TimePickerComponent, PatientAddEditComponent, PatientAppointmentsComponent, 
    MatDatepickerComponent, MatDatepicker2Component, ScheduleTimeComponent, KaysDatepickerComponent,
    DoctorShiftComponent, NextAvailableComponent, MatTreeViewComponent, SelectAutocompleteServerComponent, 
    DatePickerComponent, GptAutocompleteComponent, TimeInputMaskDirective, TimeInputComponent,
    W3AutocompleteComponent, PatientSelectAutoComponent, ],

  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
})
export class SharedComponentsModule { }
