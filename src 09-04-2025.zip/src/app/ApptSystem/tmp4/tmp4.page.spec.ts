import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Tmp4Page } from './tmp4.page';

describe('Tmp4Page', () => {
  let component: Tmp4Page;
  let fixture: ComponentFixture<Tmp4Page>;

  beforeEach(() => {
    fixture = TestBed.createComponent(Tmp4Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
