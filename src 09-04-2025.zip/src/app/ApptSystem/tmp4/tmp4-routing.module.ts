import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Tmp4Page } from './tmp4.page';

const routes: Routes = [
  {
    path: '',
    component: Tmp4Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Tmp4PageRoutingModule {}
