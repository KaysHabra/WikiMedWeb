import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tmp4',
  templateUrl: './tmp4.page.html',
  styleUrls: ['./tmp4.page.scss'],
})
export class Tmp4Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
