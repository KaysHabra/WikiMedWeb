import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Tmp4PageRoutingModule } from './tmp4-routing.module';

import { Tmp4Page } from './tmp4.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Tmp4PageRoutingModule
  ],
  declarations: [Tmp4Page]
})
export class Tmp4PageModule {}
