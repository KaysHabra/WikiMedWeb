import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deep-datepicker',
  templateUrl: './deep-datepicker.component.html',
  styleUrls: ['./deep-datepicker.component.scss'],
})
export class DeepDatepickerComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
