import { TimeInputMaskDirective } from './time-input-mask.directive';

describe('TimeInputMaskDirective', () => {
  it('should create an instance', () => {
    const directive = new TimeInputMaskDirective();
    expect(directive).toBeTruthy();
  });
});
