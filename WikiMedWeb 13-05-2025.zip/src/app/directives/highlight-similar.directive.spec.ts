import { HighlightSimilarDirective } from './highlight-similar.directive';

describe('HighlightSimilarDirective', () => {
  it('should create an instance', () => {
    const directive = new HighlightSimilarDirective();
    expect(directive).toBeTruthy();
  });
});
